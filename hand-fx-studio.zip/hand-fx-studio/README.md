# 핸드 이펙트 스튜디오

웹캠 앞 손동작으로 불꽃·번개·충격파 효과를 만드는 정적 웹앱입니다. 서버·DB 없이 브라우저에서만 동작합니다.

## 구조
index.html / css/style.css / js/(config, camera, handTracker, gestureEngine, themes, particles, effects, recorder, main).js

## 로컬 실행
ES Module과 카메라 때문에 `file://`로는 열 수 없습니다. 이 폴더에서 `python -m http.server 8000` 실행 후 http://localhost:8000 접속.

## GitHub Pages 배포
1. 새 저장소 생성 (예: hand-fx-studio, Public)
2. 이 폴더의 파일 전체를 저장소 루트에 업로드/푸시
3. Settings → Pages → Deploy from a branch → main / (root) → Save
4. 1~2분 뒤 https://<계정명>.github.io/hand-fx-studio/ 접속 후 카메라 허용

## 조정
- js/config.js : 인식 민감도, 파티클 상한, MediaPipe 버전
- js/themes.js : 테마 색·움직임
- js/effects.js : 제스처별 효과
