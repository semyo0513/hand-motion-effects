/**
 * main.js — 앱 시작점: 초기화, 메인 루프, UI 연결
 */
import { CONFIG } from './config.js';
import { startCamera, explainCameraError } from './camera.js';
import { HandTracker } from './handTracker.js';
import { GestureEngine } from './gestureEngine.js';
import { ParticleSystem } from './particles.js';
import { EffectManager } from './effects.js';
import { THEMES } from './themes.js';
import { Recorder } from './recorder.js';

const $ = (id) => document.getElementById(id);

const els = {
  stage: $('stage'),
  canvas: $('view'),
  video: $('cam'),
  hud: $('hud'),
  intro: $('intro'),
  startBtn: $('startBtn'),
  status: $('status'),
  guide: $('guide'),
  guideBtn: $('guideBtn'),
  guideClose: $('guideClose'),
  dock: $('dock'),
  themes: $('themes'),
  stable: $('stable'),
  intensity: $('intensity'),
  mirror: $('mirror'),
  debug: $('debug'),
  captureBtn: $('captureBtn'),
  recordBtn: $('recordBtn'),
  fsBtn: $('fsBtn'),
};

const ctx = els.canvas.getContext('2d');
const tracker = new HandTracker();
const gestures = new GestureEngine();
const particles = new ParticleSystem(CONFIG.particles.max);
const effects = new EffectManager(particles);
const recorder = new Recorder(els.canvas);

const state = { running: false, mirror: true, debug: false, W: 1280, H: 720 };
const GESTURE_LABEL = {
  open: '손바닥',
  fist: '주먹',
  pinch: '핀치',
  point: '검지',
  peace: 'V',
  thumbsUp: '엄지 척',
  none: '-',
};
const HAND_LINES = [
  [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [17, 18], [18, 19], [19, 20], [0, 17],
];

// 모션 줄이기 설정을 존중: 화면 흔들림 끄기
if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  effects.shakeEnabled = false;
}

/* ===================== UI ===================== */

function setStatus(msg, isError = false) {
  els.status.textContent = msg;
  els.status.classList.toggle('error', isError);
}

function buildThemeButtons() {
  els.themes.innerHTML = '';
  THEMES.forEach((t, i) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'chip';
    b.setAttribute('role', 'radio');
    b.setAttribute('aria-checked', String(i === effects.themeIndex));
    b.innerHTML = `<i style="background:${t.swatch}"></i>${t.label}`;
    b.addEventListener('click', () => effects.setTheme(i));
    els.themes.appendChild(b);
  });
}

function refreshThemeButtons() {
  [...els.themes.children].forEach((b, i) => b.setAttribute('aria-checked', String(i === effects.themeIndex)));
}
effects.onThemeChange = refreshThemeButtons;

function bindControls() {
  els.stable.addEventListener('input', () => gestures.setStableFrames(els.stable.value));
  els.intensity.addEventListener('input', () => effects.setIntensity(els.intensity.value));
  els.mirror.addEventListener('change', () => {
    state.mirror = els.mirror.checked;
    effects.reset();
  });
  els.debug.addEventListener('change', () => (state.debug = els.debug.checked));

  els.guideBtn.addEventListener('click', () => (els.guide.hidden = !els.guide.hidden));
  els.guideClose.addEventListener('click', () => (els.guide.hidden = true));

  els.captureBtn.addEventListener('click', async () => {
    try {
      await recorder.capture();
    } catch (e) {
      alert(e.message);
    }
  });

  els.recordBtn.addEventListener('click', () => {
    try {
      if (recorder.recording) {
        recorder.stop();
        els.recordBtn.textContent = '녹화 시작';
        els.recordBtn.classList.remove('on');
      } else {
        recorder.start();
        els.recordBtn.textContent = '녹화 중지 (저장)';
        els.recordBtn.classList.add('on');
      }
    } catch (e) {
      alert(e.message);
    }
  });

  els.fsBtn.addEventListener('click', () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else if (els.stage.requestFullscreen) els.stage.requestFullscreen();
  });

  // 키보드 단축키: 1~5 테마, D 디버그, G 가이드
  window.addEventListener('keydown', (e) => {
    if (e.target && ['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;
    const n = Number(e.key);
    if (n >= 1 && n <= THEMES.length) effects.setTheme(n - 1);
    else if (e.key === 'd' || e.key === 'D') {
      els.debug.checked = !els.debug.checked;
      state.debug = els.debug.checked;
    } else if (e.key === 'g' || e.key === 'G') els.guide.hidden = !els.guide.hidden;
  });

  if (!Recorder.supported()) {
    els.recordBtn.disabled = true;
    els.recordBtn.title = '이 브라우저는 녹화를 지원하지 않습니다';
  }
}

/* ===================== 시작 ===================== */

async function start() {
  els.startBtn.disabled = true;
  try {
    setStatus('카메라 연결 중…');
    await startCamera(els.video);

    setStatus('손 인식 모델 불러오는 중… (처음에는 몇 초 걸릴 수 있어요)');
    await tracker.init();

    state.W = els.video.videoWidth || 1280;
    state.H = els.video.videoHeight || 720;
    els.canvas.width = state.W;
    els.canvas.height = state.H;

    els.intro.hidden = true;
    els.dock.hidden = false;
    els.hud.hidden = false;
    state.running = true;
    requestAnimationFrame(loop);
  } catch (e) {
    console.error(e);
    const msg = e && e.name ? explainCameraError(e) : (e && e.message) || '시작하지 못했습니다.';
    setStatus(msg, true);
    els.startBtn.disabled = false;
    els.startBtn.textContent = '다시 시도';
  }
}

/* ===================== 메인 루프 ===================== */

let lastT = performance.now();
let fpsAcc = 0;
let fpsFrames = 0;
let fps = 0;

function loop(now) {
  if (!state.running) return;
  requestAnimationFrame(loop);

  const dt = Math.min((now - lastT) / 1000, 0.05);
  lastT = now;
  fpsAcc += dt;
  fpsFrames += 1;
  if (fpsAcc >= 0.5) {
    fps = Math.round(fpsFrames / fpsAcc);
    fpsAcc = 0;
    fpsFrames = 0;
  }

  const result = tracker.detect(els.video, now);
  const frame = gestures.update(result, state.W, state.H, state.mirror, now);
  effects.update(frame, dt, now);
  particles.update(dt);

  render(frame, now);
  updateHud(frame);
}

function render(frame, now) {
  const { W, H } = state;
  ctx.save();
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, W, H);

  const s = effects.shakeOffset();
  ctx.translate(s.x, s.y);

  // 카메라 영상 (거울 모드면 좌우 반전)
  ctx.save();
  if (state.mirror) {
    ctx.translate(W, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(els.video, 0, 0, W, H);
  ctx.restore();

  // 이펙트가 돋보이도록 살짝 어둡게
  ctx.fillStyle = `rgba(0,0,0,${CONFIG.render.dim})`;
  ctx.fillRect(0, 0, W, H);

  particles.draw(ctx);
  effects.draw(ctx, W, H, now);
  if (state.debug) drawDebug(frame);
  ctx.restore();
}

function drawDebug(frame) {
  ctx.save();
  ctx.lineWidth = 2;
  ctx.strokeStyle = 'rgba(120,255,160,0.9)';
  ctx.fillStyle = '#fff';
  ctx.font = '600 22px sans-serif';
  for (const h of frame.hands) {
    ctx.beginPath();
    for (const [a, b] of HAND_LINES) {
      ctx.moveTo(h.pts[a].x, h.pts[a].y);
      ctx.lineTo(h.pts[b].x, h.pts[b].y);
    }
    ctx.stroke();
    for (const p of h.pts) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
    const label = `${GESTURE_LABEL[h.gesture] || h.gesture} (${GESTURE_LABEL[h.raw] || h.raw})`;
    ctx.fillText(label, h.center.x - 40, h.center.y - h.size * 1.4);
  }
  ctx.fillText(`FPS ${fps} · ${tracker.delegate} · 파티클 ${particles.count}`, 16, state.H - 16);
  ctx.restore();
}

function updateHud(frame) {
  const parts = frame.hands.map((h) => GESTURE_LABEL[h.gesture] || '-');
  const hands = parts.length ? parts.join(' / ') : '손을 보여 주세요';
  els.hud.textContent = `${effects.theme.label} · ${hands}`;
}

/* ===================== 초기화 ===================== */

buildThemeButtons();
bindControls();
els.startBtn.addEventListener('click', start);

// 탭이 숨겨지면 녹화 중지 (실수로 길게 녹화되는 것 방지)
document.addEventListener('visibilitychange', () => {
  if (document.hidden && recorder.recording) {
    recorder.stop();
    els.recordBtn.textContent = '녹화 시작';
    els.recordBtn.classList.remove('on');
  }
});
