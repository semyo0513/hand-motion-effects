/**
 * effects.js — 제스처 → 효과 매핑과 효과 렌더링
 *
 * 매핑 표 (제스처 → 효과)
 *  open       손바닥에서 테마 효과가 피어오름
 *  fist       손 주변에서 에너지가 응축 (빛 덩어리 맥동)
 *  charge     펴기→오므리기: 빛이 손으로 빨려 들어감
 *  release    오므리기→펴기: 방사형 폭발 + 충격파 링
 *  pinch      핀치 지점에서 스파크
 *  point      검지 끝 궤적(빛나는 선)
 *  peace      두 손가락 끝에서 번개
 *  thumbsUp   다음 테마로 전환
 *  두 손 펴기  두 손 사이 에너지 구체 (크기 = 두 손 간격에 비례) + 손 사이 전류
 *  박수       전체 충격파 + 화면 흔들림
 */
import { CONFIG } from './config.js';
import { THEMES } from './themes.js';
import { getSprite } from './particles.js';

const rand = (a, b) => a + Math.random() * (b - a);
const pick = (arr) => arr[(Math.random() * arr.length) | 0];
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const TAU = Math.PI * 2;
const TRAIL_MS = 600;

/** 중점 변위 방식의 지그재그 번개 경로 */
function makeBolt(x0, y0, x1, y1, jag) {
  const pts = [{ x: x0, y: y0 }];
  const segs = 9;
  const dx = x1 - x0;
  const dy = y1 - y0;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  for (let i = 1; i < segs; i++) {
    const t = i / segs;
    const off = (Math.random() - 0.5) * jag;
    pts.push({ x: x0 + dx * t + nx * off, y: y0 + dy * t + ny * off });
  }
  pts.push({ x: x1, y: y1 });
  return pts;
}

export class EffectManager {
  /** @param {import('./particles.js').ParticleSystem} particles */
  constructor(particles) {
    this.p = particles;
    this.themeIndex = 0;
    this.intensity = 1;
    this.shakeEnabled = true;
    this.onThemeChange = null;

    this.acc = new Map(); // 발생량 누적기
    this.trails = new Map(); // 슬롯별 검지 궤적
    this.bolts = [];
    this.rings = [];
    this.cores = [];
    this.flash = 0;
    this.shake = 0;
    this.lastThemeAt = -1e9;
    this.orbR = 0;
    this.orbPos = null;
  }

  get theme() {
    return THEMES[this.themeIndex];
  }

  setTheme(i) {
    const n = THEMES.length;
    this.themeIndex = ((Math.round(i) % n) + n) % n;
    if (this.onThemeChange) this.onThemeChange(this.themeIndex);
  }

  setIntensity(v) {
    this.intensity = clamp(Number(v) || 1, 0.3, 2.5);
  }

  /** 화면 흔들림 오프셋 (px) */
  shakeOffset() {
    if (!this.shakeEnabled || this.shake <= 0.01) return { x: 0, y: 0 };
    const a = this.shake * 18;
    return { x: rand(-a, a), y: rand(-a, a) };
  }

  /* ---------------- 갱신 ---------------- */

  update(frame, dt, now) {
    this.cores.length = 0;
    for (const ev of frame.events) this._handleEvent(ev, now);
    for (const h of frame.hands) this._handleHand(h, dt, now);
    this._handleTwo(frame.two, dt);
    this._decay(dt, now);
  }

  /** 초당 perSec개 비율로 정수 개수를 뽑는 누적기 */
  _rate(key, perSec, dt) {
    const a = (this.acc.get(key) || 0) + perSec * dt * this.intensity;
    const n = Math.floor(a);
    this.acc.set(key, a - n);
    return n;
  }

  /** 테마에 맞는 기본 파티클 1개 */
  _flame(x, y, sc) {
    const t = this.theme;
    const angle = t.gravity < 0 ? -Math.PI / 2 + rand(-0.6, 0.6) : rand(0, TAU);
    const sp = rand(30, 130) * sc;
    this.p.emit({
      x,
      y,
      vx: Math.cos(angle) * sp,
      vy: Math.sin(angle) * sp,
      life: rand(t.life[0], t.life[1]),
      size: rand(t.size[0], t.size[1]) * sc,
      rgb: pick(t.palette),
      gravity: t.gravity,
      jitter: t.jitter,
      drag: 0.97,
    });
  }

  /** 방사형 폭발 */
  _burst(x, y, count, vMin, vMax, sc) {
    const t = this.theme;
    for (let i = 0; i < count; i++) {
      const a = rand(0, TAU);
      const sp = rand(vMin, vMax);
      this.p.emit({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rand(0.5, 1.2),
        size: rand(t.size[0], t.size[1]) * sc,
        rgb: pick(t.palette),
        gravity: t.gravity * 0.5,
        jitter: t.jitter * 0.5,
        drag: 0.94,
      });
    }
  }

  _addRing(x, y, r0, speed, life, w) {
    this.rings.push({ x, y, r: r0, speed, life, maxLife: life, w });
  }

  _handleEvent(ev, now) {
    const t = this.theme;
    const sc = clamp((ev.size || 100) / 110, 0.6, 2.2);
    switch (ev.type) {
      case 'enter':
        // 엄지 척: 다음 테마로 (쿨다운 적용)
        if (ev.gesture === 'thumbsUp' && now - this.lastThemeAt > CONFIG.gesture.themeCooldownMs) {
          this.lastThemeAt = now;
          this.setTheme(this.themeIndex + 1);
          this.flash = Math.max(this.flash, 0.25);
        }
        break;
      case 'charge': {
        const n = Math.round(50 * this.intensity);
        for (let i = 0; i < n; i++) {
          const a = rand(0, TAU);
          const r = ev.size * rand(2.2, 3.2);
          this.p.emit({
            x: ev.x + Math.cos(a) * r,
            y: ev.y + Math.sin(a) * r,
            tx: ev.x,
            ty: ev.y,
            pull: 14,
            life: rand(0.3, 0.5),
            size: rand(6, 14) * sc,
            rgb: pick(t.palette),
            drag: 0.92,
          });
        }
        break;
      }
      case 'release':
        this._burst(ev.x, ev.y, Math.round(90 * this.intensity), 300, 700, sc);
        this._addRing(ev.x, ev.y, ev.size * 0.4, 520, 0.6, 6);
        this.shake = Math.max(this.shake, 0.35);
        this.flash = Math.max(this.flash, 0.2);
        break;
      case 'clap':
        this._burst(ev.x, ev.y, Math.round(140 * this.intensity), 400, 1100, sc);
        this._addRing(ev.x, ev.y, 0, 1400, 0.8, 10);
        this._addRing(ev.x, ev.y, 60, 1150, 0.7, 6);
        this._addRing(ev.x, ev.y, 120, 900, 0.6, 4);
        this.shake = 1;
        this.flash = 0.55;
        break;
      default:
        break;
    }
  }

  _handleHand(h, dt, now) {
    const t = this.theme;
    const sc = clamp(h.size / 110, 0.6, 2.2);
    const c = h.center;

    switch (h.gesture) {
      case 'open': {
        const n = this._rate('open' + h.slot, 70, dt);
        for (let i = 0; i < n; i++) {
          const a = rand(0, TAU);
          const r = Math.sqrt(Math.random()) * h.size * 0.7;
          this._flame(c.x + Math.cos(a) * r, c.y + Math.sin(a) * r, sc);
        }
        this.cores.push({ x: c.x, y: c.y, r: h.size * 0.9, rgb: t.core, alpha: 0.35 });
        break;
      }
      case 'fist': {
        const n = this._rate('fist' + h.slot, 50, dt);
        for (let i = 0; i < n; i++) {
          const a = rand(0, TAU);
          const r = h.size * rand(1.6, 2.2);
          this.p.emit({
            x: c.x + Math.cos(a) * r,
            y: c.y + Math.sin(a) * r,
            tx: c.x,
            ty: c.y,
            pull: 6,
            life: 0.5,
            size: rand(4, 9) * sc,
            rgb: pick(t.palette),
            drag: 0.95,
          });
        }
        const pulse = 0.7 + 0.15 * Math.sin(now / 90);
        this.cores.push({ x: c.x, y: c.y, r: h.size * pulse, rgb: t.core, alpha: 0.8 });
        this.cores.push({ x: c.x, y: c.y, r: h.size * pulse * 0.4, rgb: '255,255,255', alpha: 0.7 });
        break;
      }
      case 'pinch': {
        const n = this._rate('pinch' + h.slot, 40, dt);
        for (let i = 0; i < n; i++) {
          const a = rand(0, TAU);
          const sp = rand(60, 200) * sc;
          this.p.emit({
            x: h.pinch.x,
            y: h.pinch.y,
            vx: Math.cos(a) * sp,
            vy: Math.sin(a) * sp,
            life: rand(0.25, 0.55),
            size: rand(3, 7) * sc,
            rgb: pick(t.palette),
            gravity: 200,
            drag: 0.93,
          });
        }
        this.cores.push({ x: h.pinch.x, y: h.pinch.y, r: h.size * 0.35, rgb: t.core, alpha: 0.9 });
        break;
      }
      case 'point': {
        const tip = h.tips.index;
        let arr = this.trails.get(h.slot);
        if (!arr) {
          arr = [];
          this.trails.set(h.slot, arr);
        }
        arr.push({ x: tip.x, y: tip.y, t: now });
        if (arr.length > 60) arr.shift();
        const n = this._rate('point' + h.slot, 30, dt);
        for (let i = 0; i < n; i++) this._flame(tip.x, tip.y, sc * 0.5);
        break;
      }
      case 'peace': {
        const n = this._rate('bolt' + h.slot, 14, dt);
        for (let i = 0; i < n; i++) {
          for (const tip of [h.tips.index, h.tips.middle]) {
            const base = Math.atan2(tip.y - c.y, tip.x - c.x) + rand(-0.5, 0.5);
            const len = h.size * rand(2.5, 4.5);
            this.bolts.push({
              pts: makeBolt(tip.x, tip.y, tip.x + Math.cos(base) * len, tip.y + Math.sin(base) * len, h.size * 0.7),
              life: 0.14,
              maxLife: 0.14,
              w: 2.5,
            });
            this.p.emit({
              x: tip.x,
              y: tip.y,
              vx: rand(-80, 80),
              vy: rand(-80, 80),
              life: 0.3,
              size: rand(5, 10) * sc,
              rgb: t.bolt,
              drag: 0.9,
            });
          }
        }
        break;
      }
      default:
        break;
    }
  }

  _handleTwo(two, dt) {
    const t = this.theme;
    if (two && two.bothOpen) {
      const target = clamp(two.dist * 0.28, 24, 240);
      this.orbR += (target - this.orbR) * Math.min(1, dt * 10);
      this.orbPos = two.mid;

      this.cores.push({ x: two.mid.x, y: two.mid.y, r: this.orbR, rgb: t.core, alpha: 0.9 });
      this.cores.push({ x: two.mid.x, y: two.mid.y, r: this.orbR * 0.45, rgb: '255,255,255', alpha: 0.9 });

      // 구체 주위를 도는 입자 (구심력 pull=k, 접선속도 = r·√k 이면 원운동)
      const k = 9;
      const nOrbit = this._rate('orbit', 90, dt);
      for (let i = 0; i < nOrbit; i++) {
        const a = rand(0, TAU);
        const r = this.orbR * 0.9;
        const v = r * Math.sqrt(k);
        this.p.emit({
          x: two.mid.x + Math.cos(a) * r,
          y: two.mid.y + Math.sin(a) * r,
          vx: -Math.sin(a) * v,
          vy: Math.cos(a) * v,
          tx: two.mid.x,
          ty: two.mid.y,
          pull: k,
          life: 0.5,
          size: rand(3, 8),
          rgb: pick(t.palette),
          jitter: 40,
        });
      }

      // 두 손 사이 전류
      const nLink = this._rate('link', 10, dt);
      for (let i = 0; i < nLink; i++) {
        this.bolts.push({ pts: makeBolt(two.a.x, two.a.y, two.b.x, two.b.y, 50), life: 0.12, maxLife: 0.12, w: 2 });
      }
    } else {
      this.orbR *= Math.max(0, 1 - dt * 8);
      if (this.orbR > 2 && this.orbPos) {
        this.cores.push({ x: this.orbPos.x, y: this.orbPos.y, r: this.orbR, rgb: t.core, alpha: 0.6 });
      }
    }
  }

  _decay(dt, now) {
    for (let i = this.bolts.length - 1; i >= 0; i--) {
      this.bolts[i].life -= dt;
      if (this.bolts[i].life <= 0) this.bolts.splice(i, 1);
    }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i];
      r.r += r.speed * dt;
      r.life -= dt;
      if (r.life <= 0) this.rings.splice(i, 1);
    }
    for (const arr of this.trails.values()) {
      while (arr.length && now - arr[0].t > TRAIL_MS) arr.shift();
    }
    this.flash = Math.max(0, this.flash - dt * 2.2);
    this.shake = Math.max(0, this.shake - dt * 2.5);
  }

  /* ---------------- 그리기 ---------------- */

  draw(ctx, W, H, now) {
    const t = this.theme;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // 빛 덩어리
    for (const c of this.cores) {
      ctx.globalAlpha = c.alpha;
      ctx.drawImage(getSprite(c.rgb), c.x - c.r, c.y - c.r, c.r * 2, c.r * 2);
    }

    // 충격파 링
    for (const r of this.rings) {
      const a = r.life / r.maxLife;
      ctx.globalAlpha = a;
      ctx.strokeStyle = `rgb(${t.core})`;
      ctx.lineWidth = r.w * a + 1;
      ctx.beginPath();
      ctx.arc(r.x, r.y, Math.max(0, r.r), 0, TAU);
      ctx.stroke();
    }

    // 검지 궤적
    for (const arr of this.trails.values()) {
      for (let i = 1; i < arr.length; i++) {
        const p0 = arr[i - 1];
        const p1 = arr[i];
        if (p1.t - p0.t > 120) continue; // 끊어진 구간은 잇지 않음
        const a = 1 - (now - p1.t) / TRAIL_MS;
        if (a <= 0) continue;
        ctx.globalAlpha = a;
        ctx.strokeStyle = `rgb(${t.core})`;
        ctx.lineWidth = 12 * a + 2;
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.lineTo(p1.x, p1.y);
        ctx.stroke();
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 3 * a;
        ctx.stroke();
      }
    }

    // 번개
    for (const b of this.bolts) {
      const a = b.life / b.maxLife;
      ctx.globalAlpha = a;
      ctx.beginPath();
      ctx.moveTo(b.pts[0].x, b.pts[0].y);
      for (let i = 1; i < b.pts.length; i++) ctx.lineTo(b.pts[i].x, b.pts[i].y);
      ctx.strokeStyle = `rgb(${t.bolt})`;
      ctx.lineWidth = b.w * 3;
      ctx.stroke();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = b.w;
      ctx.stroke();
    }
    ctx.restore();

    // 화면 섬광
    if (this.flash > 0.01) {
      ctx.save();
      ctx.globalAlpha = Math.min(1, this.flash);
      ctx.fillStyle = `rgb(${t.core})`;
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillRect(-40, -40, W + 80, H + 80);
      ctx.restore();
    }
  }

  /** 모든 효과 초기화 (카메라 재시작 등) */
  reset() {
    this.acc.clear();
    this.trails.clear();
    this.bolts.length = 0;
    this.rings.length = 0;
    this.cores.length = 0;
    this.flash = 0;
    this.shake = 0;
    this.orbR = 0;
    this.orbPos = null;
  }
}
