/**
 * handTracker.js — MediaPipe Hand Landmarker 래퍼
 *  - 라이브러리는 동적 import로 불러와 주소 후보를 차례로 시도한다.
 *  - GPU delegate 우선, 실패하면 CPU로 대체한다.
 */
import { CONFIG } from './config.js';

const EMPTY = { landmarks: [] };

export class HandTracker {
  constructor() {
    this.landmarker = null;
    this.delegate = '';
    this.lastVideoTime = -1;
    this.last = EMPTY;
  }

  /** 모델 로딩. 실패 시 오류를 던진다. */
  async init() {
    const mp = CONFIG.mediapipe;
    let lib = null;
    let wasmUrl = '';
    let lastError = null;

    // 1) 라이브러리 로딩 (후보 주소를 차례로 시도)
    for (const c of mp.candidates) {
      try {
        lib = await import(c.module);
        wasmUrl = c.wasm;
        break;
      } catch (e) {
        lastError = e;
        console.warn('[HandTracker] 라이브러리 로딩 실패, 다음 주소 시도:', c.module, e);
      }
    }
    if (!lib) {
      throw new Error('손 인식 라이브러리를 불러오지 못했습니다. 인터넷 연결을 확인해 주세요. (' + (lastError && lastError.message) + ')');
    }

    const { FilesetResolver, HandLandmarker } = lib;
    const vision = await FilesetResolver.forVisionTasks(wasmUrl);

    const create = (delegate) =>
      HandLandmarker.createFromOptions(vision, {
        baseOptions: { modelAssetPath: mp.modelUrl, delegate },
        runningMode: 'VIDEO',
        numHands: mp.numHands,
        minHandDetectionConfidence: mp.minDetectionConfidence,
        minHandPresenceConfidence: mp.minPresenceConfidence,
        minTrackingConfidence: mp.minTrackingConfidence,
      });

    // 2) 모델 생성 (GPU → CPU 순)
    try {
      this.landmarker = await create('GPU');
      this.delegate = 'GPU';
    } catch (e) {
      console.warn('[HandTracker] GPU 사용 불가, CPU로 대체:', e);
      this.landmarker = await create('CPU');
      this.delegate = 'CPU';
    }
  }

  /**
   * 현재 비디오 프레임에서 손을 검출한다.
   * 같은 프레임이면 이전 결과를 재사용한다.
   * @returns {{landmarks: Array<Array<{x:number,y:number,z:number}>>}}
   */
  detect(video, nowMs) {
    if (!this.landmarker) return EMPTY;
    if (video.currentTime === this.lastVideoTime) return this.last;
    this.lastVideoTime = video.currentTime;
    try {
      const r = this.landmarker.detectForVideo(video, nowMs);
      this.last = { landmarks: (r && r.landmarks) || [] };
    } catch (e) {
      console.warn('[HandTracker] 검출 오류:', e);
      this.last = EMPTY;
    }
    return this.last;
  }

  close() {
    if (this.landmarker) {
      this.landmarker.close();
      this.landmarker = null;
    }
  }
}
