/**
 * gestureEngine.js — 랜드마크 → 제스처 판정, 상태 전이/두 손 이벤트 생성
 *
 * 입력 : HandTracker 결과(정규화 좌표) + 캔버스 크기
 * 출력 : { hands[], two, events[] }  (모든 좌표는 캔버스 픽셀 기준)
 *
 * 제스처 이름: open | fist | pinch | point | peace | thumbsUp | none
 * 이벤트     : enter(동작 확정) | charge(펴기→오므리기) | release(오므리기→펴기) | clap(박수)
 */
import { CONFIG } from './config.js';

const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

// [손가락 끝, PIP] — 검지, 중지, 약지, 새끼
const FINGER_JOINTS = [
  [8, 6],
  [12, 10],
  [16, 14],
  [20, 18],
];

/** 손바닥 중심: 손목 + 각 손가락 MCP 평균 */
function palmCenter(pts) {
  const ids = [0, 5, 9, 13, 17];
  let x = 0;
  let y = 0;
  for (const i of ids) {
    x += pts[i].x;
    y += pts[i].y;
  }
  return { x: x / ids.length, y: y / ids.length };
}

export class GestureEngine {
  constructor() {
    this.stableFrames = CONFIG.gesture.stableFrames;
    this.slots = [this._newSlot(), this._newSlot()];
    this.palmHist = [];
    this.lastClapAt = -1e9;
  }

  /** 인식 안정도(디바운스 프레임 수) 설정 — 1~8로 제한 */
  setStableFrames(n) {
    const v = Math.round(Number(n));
    this.stableFrames = Number.isFinite(v) ? Math.min(8, Math.max(1, v)) : CONFIG.gesture.stableFrames;
  }

  _newSlot() {
    return {
      active: false,
      last: null,
      lastSeen: 0,
      stable: 'none',
      cand: 'none',
      candCount: 0,
      lastOpenAt: -1e9,
      lastFistAt: -1e9,
    };
  }

  /** 정규화 좌표 → 캔버스 픽셀 좌표 (거울 모드면 x 반전) */
  _toPixels(lm, W, H, mirror) {
    return lm.map((p) => ({ x: (mirror ? 1 - p.x : p.x) * W, y: p.y * H }));
  }

  /** 한 손의 순간 제스처 판정 */
  _classify(pts, size) {
    const w = pts[0];
    const margin = CONFIG.gesture.fingerMargin;
    const [i, m, r, p] = FINGER_JOINTS.map(([tip, pip]) => dist(pts[tip], w) > dist(pts[pip], w) * margin);

    // 모든 손가락이 접힘 → 엄지 척 또는 주먹
    if (!i && !m && !r && !p) {
      const thumbUp = pts[4].y < pts[5].y - size * 0.35 && dist(pts[4], w) > size * 1.1;
      return thumbUp ? 'thumbsUp' : 'fist';
    }
    if (i && m && r && p) return 'open';

    const pinchClose = dist(pts[4], pts[8]) < size * CONFIG.gesture.pinchRatio;
    if (pinchClose && (m || r || p)) return 'pinch';
    if (i && m && !r && !p) return 'peace';
    if (i && !m && !r && !p) return 'point';
    return 'none';
  }

  /** 디바운스 + 전이 이벤트 생성 */
  _stabilize(s, raw, now, center, size, slot, events) {
    if (raw === s.cand) s.candCount += 1;
    else {
      s.cand = raw;
      s.candCount = 1;
    }

    if (s.candCount >= this.stableFrames && s.cand !== s.stable) {
      const prev = s.stable;
      s.stable = s.cand;
      const base = { slot, x: center.x, y: center.y, size };
      const T = CONFIG.gesture.transitionMs;
      events.push({ type: 'enter', gesture: s.stable, from: prev, ...base });
      if (s.stable === 'fist' && s.lastOpenAt > s.lastFistAt && now - s.lastOpenAt < T) {
        events.push({ type: 'charge', ...base });
      }
      if (s.stable === 'open' && s.lastFistAt > s.lastOpenAt && now - s.lastFistAt < T) {
        events.push({ type: 'release', ...base });
      }
    }
    if (s.stable === 'open') s.lastOpenAt = now;
    if (s.stable === 'fist') s.lastFistAt = now;
  }

  /**
   * 프레임 갱신
   * @param {{landmarks:Array}} result HandTracker 결과
   * @param {number} W 캔버스 너비
   * @param {number} H 캔버스 높이
   * @param {boolean} mirror 거울 모드
   * @param {number} now 현재 시각(ms)
   */
  update(result, W, H, mirror, now) {
    const events = [];
    const hands = [];

    const detected = (result.landmarks || []).map((lm) => {
      const pts = this._toPixels(lm, W, H, mirror);
      return { pts, center: palmCenter(pts), size: Math.max(1, dist(pts[0], pts[9])) };
    });

    // ① 슬롯 배정: 이전 위치와 가까운 슬롯 우선, 없으면 빈 슬롯
    const used = new Set();
    const assigned = [];
    for (const d of detected) {
      let best = -1;
      let bestDist = Infinity;
      this.slots.forEach((s, i) => {
        if (used.has(i) || !s.active) return;
        const dd = dist(s.last, d.center);
        if (dd < bestDist && dd < W * 0.4) {
          bestDist = dd;
          best = i;
        }
      });
      if (best < 0) best = this.slots.findIndex((s, i) => !used.has(i) && !s.active);
      if (best < 0) best = this.slots.findIndex((s, i) => !used.has(i));
      if (best < 0) continue;
      used.add(best);
      assigned.push({ slot: best, ...d });
    }

    // ② 슬롯별 판정
    for (const a of assigned) {
      const s = this.slots[a.slot];
      s.active = true;
      s.last = a.center;
      s.lastSeen = now;
      const raw = this._classify(a.pts, a.size);
      this._stabilize(s, raw, now, a.center, a.size, a.slot, events);
      hands.push({
        slot: a.slot,
        center: a.center,
        size: a.size,
        gesture: s.stable,
        raw,
        pts: a.pts,
        tips: { thumb: a.pts[4], index: a.pts[8], middle: a.pts[12], ring: a.pts[16], pinky: a.pts[20] },
        pinch: { x: (a.pts[4].x + a.pts[8].x) / 2, y: (a.pts[4].y + a.pts[8].y) / 2 },
      });
    }

    // ③ 오래 안 보인 손은 슬롯 초기화
    this.slots.forEach((s, i) => {
      if (!used.has(i) && s.active && now - s.lastSeen > CONFIG.gesture.lostMs) {
        this.slots[i] = this._newSlot();
      }
    });

    // ④ 두 손 조합 (거리, 두 손 펴기, 박수)
    let two = null;
    if (assigned.length === 2) {
      const [a, b] = assigned;
      const d = dist(a.center, b.center);
      const avg = (a.size + b.size) / 2;
      const mid = { x: (a.center.x + b.center.x) / 2, y: (a.center.y + b.center.y) / 2 };
      const bothOpen = this.slots[a.slot].stable === 'open' && this.slots[b.slot].stable === 'open';

      this.palmHist.push({ t: now, d });
      while (this.palmHist.length && now - this.palmHist[0].t > 350) this.palmHist.shift();
      const maxD = Math.max(...this.palmHist.map((h) => h.d));

      if (d < avg * 1.7 && maxD > avg * 3.4 && now - this.lastClapAt > CONFIG.gesture.clapCooldownMs) {
        this.lastClapAt = now;
        this.palmHist.length = 0;
        events.push({ type: 'clap', x: mid.x, y: mid.y, size: avg });
      }
      two = { a: a.center, b: b.center, mid, dist: d, bothOpen, avgSize: avg };
    } else {
      this.palmHist.length = 0;
    }

    return { hands, two, events };
  }
}
