/**
 * config.js — 전역 설정 (수치는 이 파일에서만 조정)
 *
 * MediaPipe 주소 안내
 *  - 모델(.task)과 wasm 경로 형식은 MediaPipe 공식 문서 예제와 동일합니다.
 *  - 아래 `candidates`는 위에서부터 차례로 시도합니다.
 *    1순위: 버전 고정 주소 (VERSION 값은 필요 시 바꾸세요)
 *    2순위: 공식 문서의 기본(버전 미지정) 주소 — 1순위가 실패하면 자동 대체
 */
const MP_VERSION = '0.10.14';
const CDN = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision';

export const CONFIG = {
  mediapipe: {
    candidates: [
      { module: `${CDN}@${MP_VERSION}/vision_bundle.mjs`, wasm: `${CDN}@${MP_VERSION}/wasm` },
      { module: `${CDN}/vision_bundle.mjs`, wasm: `${CDN}@latest/wasm` },
    ],
    modelUrl:
      'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
    numHands: 2,
    minDetectionConfidence: 0.6,
    minPresenceConfidence: 0.5,
    minTrackingConfidence: 0.5,
  },

  particles: {
    max: 1600, // 동시 파티클 상한 (저사양이면 낮추세요)
  },

  gesture: {
    stableFrames: 3, // 같은 동작이 연속 N프레임 유지되어야 확정
    fingerMargin: 1.1, // 손가락 끝이 PIP보다 손목에서 이 배수 이상 멀면 '펴짐'
    pinchRatio: 0.3, // 엄지-검지 끝 거리 < 손 크기 × 이 값 → 핀치
    lostMs: 300, // 손이 사라져도 이 시간 동안은 상태 유지
    transitionMs: 1500, // 펴기↔오므리기 전환으로 인정하는 최대 간격
    clapCooldownMs: 1000, // 박수 재발동 대기
    themeCooldownMs: 1200, // 엄지 척 테마 전환 대기
  },

  render: {
    dim: 0.15, // 영상 위에 깔아 이펙트를 돋보이게 하는 어둡기(0~1)
  },
};
